module.exports=[63880,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_fitness-weekend_page_actions_ba529495.js.map